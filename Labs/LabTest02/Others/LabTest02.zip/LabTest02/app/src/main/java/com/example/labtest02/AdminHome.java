package com.example.labtest02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AdminHome extends AppCompatActivity {

    private EditText slot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        slot = (EditText)findViewById(R.id.slot);
    }

    public void onAdd(View view)
    {
        Toast toast = Toast.makeText(this, "Slot has been added", Toast.LENGTH_SHORT);
        toast.show();
    }
}