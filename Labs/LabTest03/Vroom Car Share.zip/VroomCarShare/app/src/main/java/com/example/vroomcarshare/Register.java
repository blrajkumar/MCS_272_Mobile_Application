package com.example.vroomcarshare;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import android.os.Bundle;

public class Register extends AppCompatActivity {

    EditText fname, lname, email, phnumber, dob, dlnumber, street, city, state, zipcode;
    Button register;
    ProgressDialog progressDialog;
    ConnectionClass connectionClass;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);


        fname= (EditText) findViewById(R.id.fname);
        lname= (EditText) findViewById(R.id.lname);
        email= (EditText) findViewById(R.id.email);
        phnumber= (EditText) findViewById(R.id.phnumber);
        dob= (EditText) findViewById(R.id.dob);
        dlnumber= (EditText) findViewById(R.id.dlnumber);
        street= (EditText) findViewById(R.id.street);
        city= (EditText) findViewById(R.id.city);
        state= (EditText) findViewById(R.id.state);
        zipcode= (EditText) findViewById(R.id.zipcode);
        register= (Button) findViewById(R.id.register);

        connectionClass = new ConnectionClass();
        progressDialog=new ProgressDialog(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Register.Doregister doregister = new Register.Doregister();
                doregister.execute("");
            }
        });
    }

    public class Doregister extends AsyncTask<String,String,String>
    {


        String fnamestr=fname.getText().toString();
        String lnamestr=lname.getText().toString();
        String emailstr=email.getText().toString();
        String phnumberstr=phnumber.getText().toString();
        String dobstr=dob.getText().toString();
        String dlnumberstr=dlnumber.getText().toString();
        String streetstr=street.getText().toString();
        String citystr=city.getText().toString();
        String statestr=state.getText().toString();
        String zipstr=zipcode.getText().toString();

        String z="";
        boolean isSuccess=false;

        @Override
        protected void onPreExecute() {
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {

            if(fnamestr.trim().equals("")|| lnamestr.trim().equals("") || emailstr.trim().equals("")
                    || phnumberstr.trim().equals("") || dobstr.trim().equals("") || dlnumberstr.trim().equals("")
                    || streetstr.trim().equals("") || citystr.trim().equals("") || statestr.trim().equals("")
                    || zipstr.trim().equals("") )
                z = "Please enter all fields....";
            else
            {
                try {
                    Connection con = connectionClass.CONN();
                    if (con == null) {
                        z = "Please check your internet connection";
                    } else {
                        String query="insert into customer values('102','"+fnamestr+"','"+lnamestr+"','"+emailstr+"','"+phnumberstr+"', '"+dobstr+"', '"+dlnumberstr+"', '"+streetstr+"', '"+citystr+"', '"+statestr+"', '"+zipstr+"'  )";
                        Statement stmt = con.createStatement();
                        stmt.executeUpdate(query);

                        z = "Register successfull";
                        isSuccess=true;
                    }
                }
                catch (Exception ex)
                {
                    isSuccess = false;
                    z = "Exceptions"+ex;
                }
            }
            return z;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();
            if(isSuccess) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                builder.setTitle("Please make note of your login credentials");
                builder.setMessage("Username : "+fnamestr+"\nPassword : "+lnamestr+zipstr);
                builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        startActivity(new Intent(Register.this,Welcome.class));
                    }
                });
                builder.show();
            }
            progressDialog.hide();
        }
    }


    private class Dologin extends AsyncTask<String,String,String>{
        String namestr=fname.getText().toString();
        String emailstr=email.getText().toString();
        String passstr=lname.getText().toString();
        String z="";
        boolean isSuccess=false;
        String nm,em,password;


        @Override
        protected void onPreExecute() {
            progressDialog.setMessage("Loading...");
            progressDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            return z;        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();


            if(isSuccess) {
                Intent intent=new Intent(Register.this,Welcome.class);
                intent.putExtra("name",namestr);
                startActivity(intent);
            }
            progressDialog.hide();

        }
    }
}
