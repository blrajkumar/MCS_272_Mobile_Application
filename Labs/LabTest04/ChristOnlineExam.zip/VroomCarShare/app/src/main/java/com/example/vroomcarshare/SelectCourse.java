package com.example.vroomcarshare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SelectCourse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_course);
    }

    public void strt(View v)
    {
        Intent intent=new Intent(SelectCourse.this, QandA.class);
        startActivity(intent);
    }
}